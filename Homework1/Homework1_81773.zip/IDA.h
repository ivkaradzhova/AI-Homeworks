#pragma once
#include "State.h"

void IterativeDeepeningAStar(State start_state);