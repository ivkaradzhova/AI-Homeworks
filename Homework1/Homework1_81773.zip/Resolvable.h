#pragma once
#include "State.h"

bool state_is_resolvable(State st);